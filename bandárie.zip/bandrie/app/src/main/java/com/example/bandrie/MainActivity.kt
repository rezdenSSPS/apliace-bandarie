package com.example.bandrie // Your package name

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import android.telephony.SmsManager
import android.util.Log
import android.view.View
import android.widget.AdapterView // For explicit listener type
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.*

class MainActivity : AppCompatActivity() {

    // --- UI Elements ---
    private lateinit var scanButton: Button
    private lateinit var deviceListView: ListView
    private lateinit var statusTextView: TextView
    private lateinit var messageEditText: EditText
    private lateinit var sendButton: Button
    private lateinit var modeSwitch: Switch
    private lateinit var espTimeTextView: TextView
    private lateinit var targetSmsNumberEditText: EditText

    // --- Mode State ---
    private var isRemoteMode = false

    // --- Bluetooth ---
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private var bluetoothSocket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null
    private var inputStream: InputStream? = null
    private var connectedDevice: BluetoothDevice? = null
    private var isConnecting = false
    private var isConnected = false
    private var keepReadingBluetoothData = false

    // --- Device List ---
    private val discoveredDevicesSet = mutableSetOf<String>()
    private val discoveredDevicesMap = mutableMapOf<String, BluetoothDevice>()
    private lateinit var listAdapter: ArrayAdapter<String>

    // --- Coroutine Scope ---
    private val activityScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // --- Receivers ---
    private lateinit var smsReceiver: SmsReceiver
    private lateinit var localSmsHandler: BroadcastReceiver
    private lateinit var discoveryReceiver: BroadcastReceiver
    private var discoveryReceiverRegistered = false

    // For storing pending SMS data if permission was denied and needs re-request
    private var pendingSmsTargetNumber: String? = null
    private var pendingSmsTimeValue: Int? = null
    private var isInitializedAfterPermissions = false

    companion object {
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val TAG = "MainActivity_SPP"
        const val ESP_TIME_UPDATE_PREFIX = "TIME_UPDATE:"
        const val ESP_CMD_SET_TIMER_PREFIX = "SET_TIMER:"
        const val ESP_CMD_SUBTRACT_MINUTES_PREFIX = "SUBTRACT:"
        const val SMS_COMMAND_PREFIX_FOR_PHONE2 = "ESP_BOMB_TIME:"
        const val ACTION_SMS_NUMBER_RECEIVED = "com.example.bandrie.ACTION_SMS_NUMBER_RECEIVED"
        const val EXTRA_SMS_NUMBER = "com.example.bandrie.EXTRA_SMS_NUMBER"
        const val ACTION_REMOTE_TIME_UPDATE_RECEIVED = "com.example.bandrie.ACTION_REMOTE_TIME_UPDATE_RECEIVED"
        const val EXTRA_REMOTE_TIME_MINUTES = "com.example.bandrie.EXTRA_REMOTE_TIME_MINUTES"
    }

    private val requiredPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        arrayOf( Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS)
    } else {
        arrayOf(Manifest.permission.BLUETOOTH, Manifest.permission.BLUETOOTH_ADMIN, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS)
    }

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            var allEssentialGranted = true
            var sendSmsJustGranted = false
            var criticalBtOrLocationDenied = false

            Log.d(TAG, "Permission Launcher results:")
            permissions.entries.forEach { entry ->
                Log.d(TAG, "  ${entry.key} = ${entry.value}")
                if (!entry.value) {
                    if (entry.key != Manifest.permission.SEND_SMS) allEssentialGranted = false
                    if (entry.key == Manifest.permission.BLUETOOTH_CONNECT || entry.key == Manifest.permission.BLUETOOTH_SCAN || entry.key == Manifest.permission.ACCESS_FINE_LOCATION) criticalBtOrLocationDenied = true
                } else if (entry.key == Manifest.permission.SEND_SMS) {
                    sendSmsJustGranted = true
                }
            }

            if (allEssentialGranted) {
                Log.d(TAG, "All essential permissions appear granted.")
                if (!isInitializedAfterPermissions) initializeAfterPermissions()

                if (sendSmsJustGranted) {
                    Toast.makeText(this, "SMS Sending Permission Granted!", Toast.LENGTH_SHORT).show()
                    if (pendingSmsTargetNumber != null && pendingSmsTimeValue != null) {
                        Log.i(TAG, "Retrying pending SMS to $pendingSmsTargetNumber with time $pendingSmsTimeValue")
                        sendTimeUpdateSmsToPhone2(pendingSmsTargetNumber!!, pendingSmsTimeValue!!)
                        pendingSmsTargetNumber = null; pendingSmsTimeValue = null
                    }
                }
            } else {
                Log.w(TAG, "Not all essential permissions granted. Critical BT/Location denied: $criticalBtOrLocationDenied")
                Toast.makeText(this, if(criticalBtOrLocationDenied) "Critical BT/Location permissions denied." else "Some permissions denied.", Toast.LENGTH_LONG).show()
            }
            if (permissions.containsKey(Manifest.permission.SEND_SMS) && permissions[Manifest.permission.SEND_SMS] == false) {
                Log.w(TAG, "SEND_SMS permission was specifically DENIED.")
                Toast.makeText(this, "SMS Sending Permission Denied. Updates won't be sent.", Toast.LENGTH_LONG).show()
                pendingSmsTargetNumber = null; pendingSmsTimeValue = null
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.d(TAG, "onCreate called")

        modeSwitch = findViewById(R.id.modeSwitch)
        scanButton = findViewById(R.id.scanButton)
        deviceListView = findViewById(R.id.deviceListView)
        statusTextView = findViewById(R.id.statusTextView)
        messageEditText = findViewById(R.id.messageEditText)
        sendButton = findViewById(R.id.sendButton)
        espTimeTextView = findViewById(R.id.espTimeTextView)
        targetSmsNumberEditText = findViewById(R.id.targetSmsNumberEditText)

        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        deviceListView.adapter = listAdapter

        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager?
        bluetoothManager?.adapter?.let { bluetoothAdapter = it } ?: run {
            Log.e(TAG, "Bluetooth not supported/Manager error"); Toast.makeText(this, "Bluetooth not supported", Toast.LENGTH_LONG).show(); finish(); return
        }

        smsReceiver = SmsReceiver()
        setupDiscoveryReceiver()
        setupLocalSmsHandler() // This also registers the localSmsHandler

        modeSwitch.setOnCheckedChangeListener { _, isChecked ->
            isRemoteMode = isChecked; Log.d(TAG, "Mode switched. Remote: $isRemoteMode")
            updateUiForMode()
        }
        scanButton.setOnClickListener { if (!isRemoteMode) startDiscoveryOrListPaired() }
        sendButton.setOnClickListener {
            if (isRemoteMode) { Toast.makeText(this, "Sending inactive in Remote Mode.", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val message = messageEditText.text.toString()
            if (message.isNotEmpty()) {
                val cmd = if (message.toIntOrNull() != null) "$ESP_CMD_SUBTRACT_MINUTES_PREFIX$message\n"
                else if (message.uppercase().startsWith(ESP_CMD_SET_TIMER_PREFIX)) "$message\n"
                else { Toast.makeText(this, "Unknown command.", Toast.LENGTH_LONG).show(); "$message\n" }
                sendMessageToEsp(cmd)
            } else Toast.makeText(this, "Message empty", Toast.LENGTH_SHORT).show()
        }
        deviceListView.setOnItemClickListener { parent: AdapterView<*>, view: View, position: Int, id: Long ->
            Log.d(TAG, "Item clicked: pos=$position, id=$id")
            if (!isRemoteMode) handleDeviceSelection(position)
        }

        updateUiForMode() // Initial UI state
        if (!hasRequiredPermissions()) requestRequiredPermissions() else initializeAfterPermissions()
    }

    private fun requestRequiredPermissions() {
        Log.d(TAG, "Requesting permissions: ${requiredPermissions.joinToString()}")
        requestPermissionLauncher.launch(requiredPermissions)
    }

    private fun initializeAfterPermissions() {
        Log.d(TAG, "initializeAfterPermissions called.")
        isInitializedAfterPermissions = true
        if (hasPermission(Manifest.permission.RECEIVE_SMS) && hasPermission(Manifest.permission.READ_SMS)) {
            registerSmsReceiver()
        } else {
            Log.w(TAG, "SMS RX permissions not granted.")
        }
        if (!isRemoteMode) {
            if (!bluetoothAdapter.isEnabled && hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
                Toast.makeText(this, "Please enable Bluetooth for Direct BT mode.", Toast.LENGTH_LONG).show()
            }
            // Discovery receiver is registered when switching to BT mode or attempting scan
        }
    }

    private fun updateUiForMode() {
        runOnUiThread {
            Log.d(TAG, "Updating UI for mode. isRemote: $isRemoteMode")
            if (isRemoteMode) {
                modeSwitch.text = "Direct BT Mode"
                scanButton.visibility = View.GONE; deviceListView.visibility = View.GONE
                targetSmsNumberEditText.visibility = View.GONE
                espTimeTextView.visibility = View.VISIBLE; if(::espTimeTextView.isInitialized) espTimeTextView.text = "Remote Time: Waiting..."
                if(::statusTextView.isInitialized) statusTextView.text = "Status: Remote Mode Active"
                if(::messageEditText.isInitialized) messageEditText.hint = "Remote commands inactive"; messageEditText.isEnabled = false; if(::sendButton.isInitialized) sendButton.isEnabled = false
                if (isConnected || isConnecting) disconnect()
                unregisterDiscoveryReceiver()
            } else { // Direct Bluetooth Mode
                modeSwitch.text = "Remote Mode"
                scanButton.visibility = View.VISIBLE; deviceListView.visibility = View.VISIBLE
                targetSmsNumberEditText.visibility = View.VISIBLE
                espTimeTextView.visibility = View.VISIBLE; if(::espTimeTextView.isInitialized) espTimeTextView.text = "ESP Time: N/A"
                if(::messageEditText.isInitialized) messageEditText.hint = "SET_TIMER:X or Number"
                if (isConnected) updateUiConnected() else if (isConnecting) updateUiConnecting() else updateUiDisconnected()
                if (hasPermission(Manifest.permission.BLUETOOTH_SCAN) && hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    if(!discoveryReceiverRegistered) registerDiscoveryReceiver()
                }
            }
        }
    }

    private fun processDataFromEsp(dataLine: String) {
        Log.d(TAG, "processDataFromEsp: '$dataLine'")
        if (dataLine.startsWith(ESP_TIME_UPDATE_PREFIX)) {
            val timeValueStr = dataLine.substringAfter(ESP_TIME_UPDATE_PREFIX).trim()
            val timeValue = timeValueStr.toIntOrNull()
            if (timeValue != null) {
                Log.i(TAG, "Parsed ESP Time Update: $timeValue min")
                if (!isRemoteMode) { // Phone 1 in Direct BT Mode
                    if(::espTimeTextView.isInitialized) espTimeTextView.text = "ESP Time: $timeValue min"
                    val targetNumber = targetSmsNumberEditText.text.toString()
                    if (targetNumber.isNotBlank()) {
                        if (hasPermission(Manifest.permission.SEND_SMS)) {
                            pendingSmsTargetNumber = null; pendingSmsTimeValue = null
                            sendTimeUpdateSmsToPhone2(targetNumber, timeValue)
                        } else {
                            Log.w(TAG, "SEND_SMS perm check failed. Storing & requesting.")
                            Toast.makeText(this, "SEND_SMS perm needed. Please grant.", Toast.LENGTH_LONG).show()
                            pendingSmsTargetNumber = targetNumber; pendingSmsTimeValue = timeValue
                            requestPermissionLauncher.launch(arrayOf(Manifest.permission.SEND_SMS))
                        }
                    } else Toast.makeText(this, "Target SMS number empty.", Toast.LENGTH_SHORT).show()
                }
            } else Log.w(TAG, "Could not parse time from ESP update: '$dataLine'")
        }
    }

    private fun setupDiscoveryReceiver() {
        discoveryReceiver = object : BroadcastReceiver() {
            @SuppressLint("MissingPermission")
            override fun onReceive(context: Context, intent: Intent) {
                if (isRemoteMode && !isConnected) return
                val action: String? = intent.action
                when (action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        var deviceName: String? = null
                        if (hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) deviceName = device?.name
                        if (device?.address != null) {
                            val finalName = deviceName ?: "Unknown Device"; val deviceInfo = "$finalName - ${device.address}"
                            if (discoveredDevicesSet.add(deviceInfo)) {
                                discoveredDevicesMap[device.address] = device
                                if(::listAdapter.isInitialized) {listAdapter.add(deviceInfo); listAdapter.notifyDataSetChanged()}
                            }
                        }
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> { if(::scanButton.isInitialized) scanButton.isEnabled = true; if(::listAdapter.isInitialized && listAdapter.isEmpty && discoveredDevicesSet.isEmpty()) listAdapter.add("No new devices found.")}
                    BluetoothAdapter.ACTION_DISCOVERY_STARTED -> { if(::scanButton.isInitialized) scanButton.isEnabled = false; updateStatus("Scanning...")}
                }
            }
        }
    }

    private fun registerDiscoveryReceiver() {
        if (!hasPermission(Manifest.permission.BLUETOOTH_SCAN) || !hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
            Log.w(TAG, "Cannot register discovery: Missing SCAN or LOCATION permission.")
            return
        }
        if (discoveryReceiverRegistered) { Log.d(TAG, "Discovery receiver already registered."); return }
        try {
            val f1=IntentFilter(BluetoothDevice.ACTION_FOUND); val f2=IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED); val f3=IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) { registerReceiver(discoveryReceiver, f1, Context.RECEIVER_NOT_EXPORTED); registerReceiver(discoveryReceiver, f2, Context.RECEIVER_NOT_EXPORTED); registerReceiver(discoveryReceiver, f3, Context.RECEIVER_NOT_EXPORTED) }
            else { registerReceiver(discoveryReceiver, f1); registerReceiver(discoveryReceiver, f2); registerReceiver(discoveryReceiver, f3) }
            Log.d(TAG, "Discovery Receiver registered."); discoveryReceiverRegistered = true
        } catch (e: Exception) { Log.e(TAG, "Err reg discovery: ${e.message}", e); discoveryReceiverRegistered = false }
    }

    private fun unregisterDiscoveryReceiver() {
        if (discoveryReceiverRegistered && ::discoveryReceiver.isInitialized) {
            try { unregisterReceiver(discoveryReceiver); Log.d(TAG, "Discovery receiver unregistered.") }
            catch (e: Exception) { Log.w(TAG, "Err unreg discovery: ${e.message}") }
            finally { discoveryReceiverRegistered = false }
        }
    }

    private fun registerSmsReceiver() {
        if (!hasPermission(Manifest.permission.RECEIVE_SMS)) { Log.w(TAG, "Cannot reg SMS RX: perm missing"); return }
        val intentFilter = IntentFilter(Telephony.Sms.Intents.SMS_RECEIVED_ACTION)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) registerReceiver(smsReceiver, intentFilter, Context.RECEIVER_EXPORTED)
            else registerReceiver(smsReceiver, intentFilter)
            Log.d(TAG, "SMS Receiver registered.")
        } catch (e: Exception) {Log.e(TAG, "Err reg SMS RX: ${e.message}", e)}
    }

    private fun setupLocalSmsHandler() {
        localSmsHandler = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    ACTION_SMS_NUMBER_RECEIVED -> {
                        val num = intent.getIntExtra(EXTRA_SMS_NUMBER, -1)
                        Log.d(TAG, "LocalSMS: Got num $num for ESP")
                        if (num > 0 && !isRemoteMode && isConnected) {
                            sendMessageToEsp("$ESP_CMD_SUBTRACT_MINUTES_PREFIX$num\n")
                            Toast.makeText(this@MainActivity, "SMS cmd ($num) sent to ESP", Toast.LENGTH_SHORT).show()
                        } else Log.w(TAG, "LocalSMS: Not sending num $num. Remote: $isRemoteMode, Connected: $isConnected")
                    }
                    ACTION_REMOTE_TIME_UPDATE_RECEIVED -> {
                        val time = intent.getIntExtra(EXTRA_REMOTE_TIME_MINUTES, -1)
                        Log.d(TAG, "LocalSMS: Got remote time $time")
                        if (isRemoteMode && time != -1 && ::espTimeTextView.isInitialized) {
                            espTimeTextView.text = "Remote Time: $time min"
                            Toast.makeText(this@MainActivity, "Remote time updated: $time min", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
        // Register it here as it doesn't depend on async permissions
        val filter = IntentFilter(); filter.addAction(ACTION_SMS_NUMBER_RECEIVED); filter.addAction(ACTION_REMOTE_TIME_UPDATE_RECEIVED)
        LocalBroadcastManager.getInstance(this).registerReceiver(localSmsHandler, filter)
        Log.d(TAG, "LocalSmsHandler setup and registered.")
    }

    private fun unregisterAllReceivers() {
        unregisterDiscoveryReceiver()
        try { if (::smsReceiver.isInitialized) unregisterReceiver(smsReceiver); Log.d(TAG, "SMS RX unreg.")} catch (e: Exception) {Log.w(TAG,"Err unreg SMS RX")}
        try { if (::localSmsHandler.isInitialized) LocalBroadcastManager.getInstance(this).unregisterReceiver(localSmsHandler); Log.d(TAG, "Local SMS unreg.")} catch (e: Exception) {Log.w(TAG,"Err unreg LocalSMS")}
    }

    private fun hasPermission(p: String): Boolean = ContextCompat.checkSelfPermission(this,p)==PackageManager.PERMISSION_GRANTED
    private fun hasRequiredPermissions(): Boolean = requiredPermissions.all { hasPermission(it) }

    @SuppressLint("MissingPermission")
    private fun handleDeviceSelection(pos: Int) {
        if (isRemoteMode || isConnecting || isConnected) return; cancelDiscovery()
        val item = if(::listAdapter.isInitialized && pos < listAdapter.count) listAdapter.getItem(pos) else null
        item ?: run {Log.w(TAG,"Invalid item selection at pos $pos"); return}
        if (item.startsWith("---") || item.contains("No ") || item.contains("Permission")) return
        val address = item.substringAfterLast(" - ", item).trim(); val device = discoveredDevicesMap[address]
        if (device != null) { if (!hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {requestRequiredPermissions(); return}; connectToDevice(device)}
        else {Toast.makeText(this, "Device data error for $address", Toast.LENGTH_SHORT).show(); Log.e(TAG,"Device not in map: $address")}
    }

    @SuppressLint("MissingPermission")
    private fun listPairedDevices() {
        if (isRemoteMode || !bluetoothAdapter.isEnabled) {Log.d(TAG, "listPaired: skipping. Remote: $isRemoteMode, BT enabled: ${bluetoothAdapter.isEnabled}"); return}
        if (!hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
            if(::listAdapter.isInitialized){listAdapter.clear(); listAdapter.add("Perm needed (paired)");listAdapter.add("--- Discovered ---");listAdapter.notifyDataSetChanged();}
            Log.w(TAG,"listPaired: Missing BT_CONNECT"); return
        }
        try {
            val paired = bluetoothAdapter.bondedDevices
            val oldDIdx = if(::listAdapter.isInitialized) listAdapter.getPosition("--- Discovered Devices ---") else -1
            val tempD = mutableListOf<String>()
            if(::listAdapter.isInitialized && oldDIdx!=-1 && oldDIdx<listAdapter.count-1) {for(i in oldDIdx+1 until listAdapter.count) tempD.add(listAdapter.getItem(i)!!)}
            if(::listAdapter.isInitialized) {listAdapter.clear(); discoveredDevicesSet.clear()} // Clear set for fresh list
            if(paired?.isNotEmpty()==true) {
                if(::listAdapter.isInitialized) listAdapter.add("--- Paired Devices ---")
                paired.forEach { d-> val n=d.name?:"Unknown"; val i="$n - ${d.address}"; if(discoveredDevicesSet.add(i)){discoveredDevicesMap[d.address]=d; if(::listAdapter.isInitialized) listAdapter.add(i)}}
            } else if(::listAdapter.isInitialized) listAdapter.add("No paired devices found.")
            if(::listAdapter.isInitialized){listAdapter.add("--- Discovered Devices ---"); tempD.forEach{if(!listAdapter.contains(it))listAdapter.add(it)}; listAdapter.notifyDataSetChanged()}
        } catch(e:SecurityException){Log.e(TAG,"listPaired SecEx: ${e.message}"); if(::listAdapter.isInitialized){listAdapter.clear();listAdapter.add("Perm Err");listAdapter.add("--- Discovered ---");listAdapter.notifyDataSetChanged()}}
    }

    private fun ArrayAdapter<String>.contains(item: String): Boolean { for(i in 0 until count) if(getItem(i)==item) return true; return false }

    @SuppressLint("MissingPermission")
    private fun startDeviceDiscovery() {
        if (isRemoteMode || !hasPermission(Manifest.permission.BLUETOOTH_SCAN) || !hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) || bluetoothAdapter.isDiscovering || !bluetoothAdapter.isEnabled || !::listAdapter.isInitialized) {
            Log.w(TAG,"startDeviceDiscovery: Preconditions not met. Remote:$isRemoteMode, SCAN:${hasPermission(Manifest.permission.BLUETOOTH_SCAN)}, LOC:${hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)}, Discovering:${bluetoothAdapter.isDiscovering}, Enabled:${bluetoothAdapter.isEnabled}")
            return
        }
        Log.d(TAG, "Starting new device discovery...")
        // Clear previous "discovered" non-paired devices from list adapter
        val itemsToKeep = mutableListOf<String>()
        var discoveredHeaderFound = false
        for (i in 0 until listAdapter.count) {
            val currentItem = listAdapter.getItem(i)!!
            if (currentItem == "--- Discovered Devices ---") { itemsToKeep.add(currentItem); discoveredHeaderFound = true; break }
            itemsToKeep.add(currentItem)
        }
        listAdapter.clear()
        itemsToKeep.forEach { listAdapter.add(it) }
        if (!discoveredHeaderFound) listAdapter.add("--- Discovered Devices ---") // Ensure header exists

        // Clear the set that tracks what's *displayed in the discovered section*
        // This requires more careful management if discoveredDevicesSet is for all devices in list.
        // For now, let's assume we only add *new* things. A better way is to clear only items after "--- Discovered ---" from the set.
        // Simplified: new devices are added if not in discoveredDevicesSet.
        // discoveredDevicesSet.clear() // This would clear paired too. Not what we want if it holds paired from listPairedDevices.

        listAdapter.notifyDataSetChanged()
        if (!bluetoothAdapter.startDiscovery()) { Log.e(TAG,"startDiscovery() failed."); updateStatus("Error starting discovery"); if(::scanButton.isInitialized) scanButton.isEnabled = true }
        else { updateStatus("Scanning for devices..."); if(::scanButton.isInitialized) scanButton.isEnabled = false}
    }

    private fun startDiscoveryOrListPaired() {
        Log.d(TAG, "startDiscoveryOrListPaired called.")
        if (isRemoteMode || !bluetoothAdapter.isEnabled || isConnecting || isConnected) {
            if(!bluetoothAdapter.isEnabled) Toast.makeText(this, "Please enable BT.", Toast.LENGTH_SHORT).show()
            if(isConnecting || isConnected) Toast.makeText(this, "Disconnect first.", Toast.LENGTH_SHORT).show()
            return
        }
        // Check specific permissions needed for this operation
        val neededPerms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (!hasPermission(Manifest.permission.BLUETOOTH_SCAN)) neededPerms.add(Manifest.permission.BLUETOOTH_SCAN)
            if (!hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) neededPerms.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (!hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) neededPerms.add(Manifest.permission.ACCESS_FINE_LOCATION)

        if (neededPerms.isNotEmpty()) {
            Log.w(TAG, "Missing discovery permissions: ${neededPerms.joinToString()}. Requesting.")
            Toast.makeText(this, "Discovery requires: ${neededPerms.joinToString()}", Toast.LENGTH_LONG).show()
            requestPermissionLauncher.launch(neededPerms.toTypedArray())
        } else {
            Log.d(TAG, "Discovery permissions granted. Proceeding.")
            if (!discoveryReceiverRegistered && ::discoveryReceiver.isInitialized) registerDiscoveryReceiver()
            if (discoveryReceiverRegistered) { // Proceed only if receiver successfully registered
                cancelDiscovery(); listPairedDevices(); startDeviceDiscovery()
            } else {
                Log.e(TAG, "Discovery receiver not registered, cannot start scan.")
                Toast.makeText(this, "Could not prepare for scan. Check permissions.", Toast.LENGTH_LONG).show()
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun cancelDiscovery() {
        if (!bluetoothAdapter.isDiscovering) { Log.d(TAG, "cancelDiscovery: not active."); return }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasPermission(Manifest.permission.BLUETOOTH_SCAN)) {
            Log.w(TAG, "cancelDiscovery: Missing BLUETOOTH_SCAN"); if(::scanButton.isInitialized && !isRemoteMode) scanButton.isEnabled = true; return
        }
        try {
            if(bluetoothAdapter.cancelDiscovery()) Log.d(TAG, "Discovery cancelled.")
            else Log.w(TAG, "cancelDiscovery() returned false.")
        } catch (e: SecurityException) {Log.e(TAG, "cancelDiscovery SecEx: ${e.message}")}
        finally { if(::scanButton.isInitialized && !isRemoteMode) scanButton.isEnabled = true }
    }

    @SuppressLint("MissingPermission")
    private fun connectToDevice(device: BluetoothDevice) {
        if (isRemoteMode || isConnecting || isConnected) return
        isConnecting = true; connectedDevice = device; val name = try { device.name ?: device.address } catch (e:SecurityException){device.address}
        updateStatus("Connecting to $name..."); updateUiConnecting(); cancelDiscovery()
        activityScope.launch(Dispatchers.IO) {
            var sock:BluetoothSocket?=null; try { sock=device.createRfcommSocketToServiceRecord(SPP_UUID); sock.connect(); bluetoothSocket=sock; outputStream=sock.outputStream; inputStream=sock.inputStream
            withContext(Dispatchers.Main){ isConnected=true;isConnecting=false; if(!isRemoteMode){updateStatus("Connected to $name");updateUiConnected();keepReadingBluetoothData=true;startBluetoothReader()}else disconnect() }
        } catch (e:Exception){ Log.e(TAG,"Connect Ex: ${e.message}", e); closeSocket(sock); withContext(Dispatchers.Main){isConnecting=false;isConnected=false;connectedDevice=null; if(!isRemoteMode){updateStatus("Connect Fail: ${e.message?.take(20)}");updateUiDisconnected()}}}
        }
    }

    private fun disconnect() {
        Log.d(TAG, "disconnect() called. isConnected: $isConnected, isConnecting: $isConnecting")
        keepReadingBluetoothData=false; val wasCon=isConnected; isConnected=false;isConnecting=false;
        closeSocket(bluetoothSocket); // Close and nullify class members inside closeSocket
        runOnUiThread{if(!isRemoteMode){updateStatus(if(wasCon)"Disconnected" else "Connection Canceled/Failed");updateUiDisconnected();if(::espTimeTextView.isInitialized)espTimeTextView.text="ESP Time: N/A"}}
    }

    private fun closeSocket(socketToClose: BluetoothSocket?) {
        Log.d(TAG, "closeSocket() called for socket: ${socketToClose?.remoteDevice?.address}")
        try{socketToClose?.outputStream?.close()}catch(e:IOException){Log.e(TAG,"Err closing BT OutStream: ${e.message}")}
        try{socketToClose?.inputStream?.close()}catch(e:IOException){Log.e(TAG,"Err closing BT InStream: ${e.message}")}
        try{socketToClose?.close()}catch(e:IOException){Log.e(TAG,"Err closing BT Socket: ${e.message}")}
        if(socketToClose == bluetoothSocket){ // Only nullify class members if it's the main socket
            bluetoothSocket=null;outputStream=null;inputStream=null;connectedDevice=null
            Log.d(TAG, "Main bluetoothSocket resources nullified.")
        }
    }

    private fun sendMessageToEsp(msg: String) {
        if(isRemoteMode || !isConnected || outputStream==null || msg.isEmpty()){ Log.w(TAG,"sendMessageToEsp: Preconditions not met."); return }
        activityScope.launch(Dispatchers.IO){try{outputStream?.write(msg.toByteArray(Charsets.UTF_8)); outputStream?.flush(); Log.i(TAG,"Msg sent: $msg"); withContext(Dispatchers.Main){if(::messageEditText.isInitialized)messageEditText.text.clear()}}catch(e:Exception){Log.e(TAG,"Send Err: ${e.message}",e);withContext(Dispatchers.Main){Toast.makeText(this@MainActivity,"Send Error",Toast.LENGTH_SHORT).show();disconnect()}}}}

    private fun startBluetoothReader() {
        if(inputStream==null || !isConnected || !keepReadingBluetoothData){ Log.w(TAG,"BT Reader not starting. Conditions: inStreamNull=${inputStream==null}, !isCon=${!isConnected}, !keepRead=${!keepReadingBluetoothData}"); return }
        Log.d(TAG, "Starting Bluetooth reader...")
        activityScope.launch(Dispatchers.IO){ val r=BufferedReader(InputStreamReader(inputStream!!, Charsets.UTF_8)); while(isActive && keepReadingBluetoothData && isConnected && bluetoothSocket?.isConnected==true){try{val l=r.readLine(); if(l!=null){Log.d(TAG,"BT Read: $l");withContext(Dispatchers.Main){processDataFromEsp(l)}}else{Log.d(TAG,"BT Read: null line (disconnected).");if(isConnected && keepReadingBluetoothData)withContext(Dispatchers.Main){disconnect()};break}}catch(e:Exception){Log.e(TAG,"BT Read Ex: ${e.message}",e);if(isActive&&keepReadingBluetoothData&&isConnected)withContext(Dispatchers.Main){disconnect()};break}}}
        Log.d(TAG, "BT Reader coroutine loop ended.")
    }

    @SuppressLint("MissingPermission")
    private fun sendTimeUpdateSmsToPhone2(phoneNum: String, timeVal: Int) {
        if (!hasPermission(Manifest.permission.SEND_SMS)) { // Double check, though already done in processDataFromEsp
            Log.w(TAG, "sendTimeUpdateSmsToPhone2: SEND_SMS permission missing at point of sending.")
            Toast.makeText(this, "Cannot send SMS, permission denied.", Toast.LENGTH_LONG).show()
            // Optionally re-request or store as pending again, though processDataFromEsp should handle primary request.
            pendingSmsTargetNumber = phoneNum; pendingSmsTimeValue = timeVal // Re-store if re-requesting here
            requestPermissionLauncher.launch(arrayOf(Manifest.permission.SEND_SMS))
            return
        }
        try { val sm=if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S)getSystemService(SmsManager::class.java)else @Suppress("DEPRECATION")SmsManager.getDefault(); val smsTxt = "$SMS_COMMAND_PREFIX_FOR_PHONE2$timeVal"; sm.sendTextMessage(phoneNum,null,smsTxt,null,null); Toast.makeText(this,"Time SMS sent to $phoneNum",Toast.LENGTH_SHORT).show(); Log.i(TAG,"SMS sent: $smsTxt to $phoneNum")}
        catch(e:Exception){Toast.makeText(this,"SMS Send Fail: ${e.message?.take(30)}",Toast.LENGTH_LONG).show(); Log.e(TAG,"Error Sending SMS",e)}
    }

    private fun updateStatus(s: String) { runOnUiThread{if(::statusTextView.isInitialized)statusTextView.text="Status: $s"} }
    private fun updateUiConnecting() { runOnUiThread{if(isRemoteMode)return@runOnUiThread;if(::scanButton.isInitialized)scanButton.isEnabled=false;if(::deviceListView.isInitialized)deviceListView.isEnabled=false;if(::messageEditText.isInitialized)messageEditText.isEnabled=false;if(::sendButton.isInitialized)sendButton.isEnabled=false} }
    private fun updateUiConnected() { runOnUiThread{if(isRemoteMode)return@runOnUiThread;if(::scanButton.isInitialized)scanButton.isEnabled=false;if(::deviceListView.isInitialized)deviceListView.isEnabled=false;if(::messageEditText.isInitialized)messageEditText.isEnabled=true;if(::sendButton.isInitialized)sendButton.isEnabled=true} }
    private fun updateUiDisconnected() { runOnUiThread{if(isRemoteMode)return@runOnUiThread;if(::scanButton.isInitialized)scanButton.isEnabled=true;if(::deviceListView.isInitialized)deviceListView.isEnabled=true;if(::messageEditText.isInitialized)messageEditText.isEnabled=false;if(::sendButton.isInitialized)sendButton.isEnabled=false} }

    override fun onDestroy() {
        super.onDestroy(); Log.d(TAG,"onDestroy: Cleaning up..."); keepReadingBluetoothData=false; unregisterAllReceivers(); disconnect(); activityScope.cancel()
    }
}
package com.example.bandrie // Make sure this matches your package

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SmsMessage
import android.util.Log
import androidx.localbroadcastmanager.content.LocalBroadcastManager

class SmsReceiver : BroadcastReceiver() {

    private val TAG_SMS = "AppSmsReceiver" // Specific TAG for this receiver


    override fun onReceive(context: Context, intent: Intent) {
        if (Telephony.Sms.Intents.SMS_RECEIVED_ACTION == intent.action) {
            val messages: Array<SmsMessage?> = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            val sb = StringBuilder()
            var sender: String? = null

            for (smsMessage in messages) {
                smsMessage?.let {
                    sb.append(it.messageBody)
                    if (sender == null) sender = it.originatingAddress
                }
            }
            val fullMessage = sb.toString().trim()
            Log.d(TAG_SMS, "SMS Received from $sender: '$fullMessage'")

            // Option 1: SMS for Phone 2 (Remote Time Update)
            if (fullMessage.startsWith(MainActivity.SMS_COMMAND_PREFIX_FOR_PHONE2)) {
                val timeStr = fullMessage.substringAfter(MainActivity.SMS_COMMAND_PREFIX_FOR_PHONE2).trim()
                val timeMinutes = timeStr.toIntOrNull()
                if (timeMinutes != null) {
                    Log.i(TAG_SMS, "Remote time update SMS parsed: $timeMinutes min")
                    val localIntent = Intent(MainActivity.ACTION_REMOTE_TIME_UPDATE_RECEIVED)
                    localIntent.putExtra(MainActivity.EXTRA_REMOTE_TIME_MINUTES, timeMinutes)
                    LocalBroadcastManager.getInstance(context).sendBroadcast(localIntent)
                    return // Handled
                }
            }
            // Option 2: SMS for Phone 1 (Command to relay to ESP32)
            else {
                val numberToRelay = fullMessage.toIntOrNull()
                if (numberToRelay != null && numberToRelay > 0) {
                    Log.i(TAG_SMS, "Numeric SMS for ESP32 command parsed: $numberToRelay")
                    val localIntent = Intent(MainActivity.ACTION_SMS_NUMBER_RECEIVED)
                    localIntent.putExtra(MainActivity.EXTRA_SMS_NUMBER, numberToRelay)
                    LocalBroadcastManager.getInstance(context).sendBroadcast(localIntent)
                    return // Handled
                }
            }
            Log.w(TAG_SMS, "SMS not recognized for app actions: '$fullMessage'")
        }
    }
}